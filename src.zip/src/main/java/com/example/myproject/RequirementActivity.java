package com.example.myproject;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.ArrayList;
import java.util.List;


public class RequirementActivity extends AppCompatActivity {
        private TextView nameTextView;
        private TextView addressTextView;
        private TextView phoneNumberTextView;
        private TextView requirementsTextView;
        private ListView requirementListView;
        private DatabaseReference databaseReference;
        private RequirementAdapter requirementAdapter;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_requirement);

                // Retrieve the passed data from the Intent extras
                String name = getIntent().getStringExtra("name");
                String address = getIntent().getStringExtra("address");
                String phoneNumber = getIntent().getStringExtra("phoneNumber");

                // Initialize the TextViews
                nameTextView = findViewById(R.id.nameTextView);
                addressTextView = findViewById(R.id.addressTextView);
                phoneNumberTextView = findViewById(R.id.phoneNumberTextView);
                requirementsTextView = findViewById(R.id.requirementsTextView);
                requirementListView = findViewById(R.id.requirementListView);

                // Set the retrieved data to the TextViews
                nameTextView.setText(name);
                addressTextView.setText(address);
                phoneNumberTextView.setText(phoneNumber);

                Button backButton = findViewById(R.id.backButton);
                backButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                                onBackPressed(); // Navigate back to the previous activity
                        }
                });

                // Get the Firebase database reference
                databaseReference = FirebaseDatabase.getInstance().getReference();

                FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
                FirebaseUser currentUser = firebaseAuth.getCurrentUser();

                if (currentUser != null) {
                        String userId = currentUser.getUid();
                        DatabaseReference userReference = databaseReference.child("users").child(userId);

                        // Retrieve the requirements for the specific user from Firebase
                        retrieveRequirements(userReference);
                } else {
                        // User is not authenticated, handle this case accordingly
                        // For example, redirect to the login screen or display an error message
                }
        }

        private void retrieveRequirements(DatabaseReference userReference) {
                DatabaseReference requirementsReference = userReference.child("requirements");

                requirementsReference.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                                List<String> requirements = new ArrayList<>();
                                for (DataSnapshot requirementSnapshot : dataSnapshot.getChildren()) {
                                        DataSnapshot countSnapshot = requirementSnapshot.child("count");
                                        DataSnapshot nameSnapshot = requirementSnapshot.child("name");

                                        if (countSnapshot.exists() && nameSnapshot.exists()) {
                                                Long requirementCount = countSnapshot.getValue(Long.class);
                                                String requirementName = nameSnapshot.getValue(String.class);

                                                if (requirementCount != null && requirementName != null) {
                                                        String requirement = requirementName + ": " + requirementCount;
                                                        requirements.add(requirement);
                                                }
                                        }
                                }

                                // Update the requirementsTextView
                                if (requirements.isEmpty()) {
                                        requirementsTextView.setText("No requirements available");
                                } else {
                                        requirementsTextView.setText("REQUIREMENTS");
                                }

                                // Create the adapter and set it to the ListView
                                requirementAdapter = new RequirementAdapter(RequirementActivity.this, requirements);
                                requirementListView.setAdapter(requirementAdapter);
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {
                                // Handle the error case
                        }
                });
        }

}