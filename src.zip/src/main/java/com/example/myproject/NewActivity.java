package com.example.myproject;

import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class NewActivity extends AppCompatActivity {

    private LinearLayout requirementLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new);

        requirementLayout = findViewById(R.id.requirementLayout);

        // Retrieve the requirements from the UserDetailsActivity
        List<String> requirements = getIntent().getStringArrayListExtra("requirements");

        // Display the requirements
        if (requirements != null && !requirements.isEmpty()) {
            for (String requirement : requirements) {
                addRequirement(requirement);
            }
        }
    }

    private void addRequirement(String requirement) {
        // Create a new TextView to display the requirement
        TextView requirementTextView = new TextView(this);
        requirementTextView.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        requirementTextView.setText(requirement);

        // Add the requirement TextView to the layout
        requirementLayout.addView(requirementTextView);
    }
}
