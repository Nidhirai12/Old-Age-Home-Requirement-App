package com.example.myproject;

public class RequirementItem {
    private String name;
    private long count;

    public RequirementItem() {
        // Default constructor required for Firebase
    }

    public RequirementItem(String name, long count) {
        this.name = name;
        this.count = count;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
