package com.example.myproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class FindHomes extends AppCompatActivity {
    private RecyclerView recyclerView;
    private InfoAdapter infoAdapter;
    List<UserData> userDataList = new ArrayList<>();

    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_homes);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        infoAdapter = new InfoAdapter();
        recyclerView.setAdapter(infoAdapter);

        // Retrieve data from Firebase Realtime Database
        databaseReference = FirebaseDatabase.getInstance().getReference("users");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                List<UserData> homeDataList = new ArrayList<>();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    UserData userData = snapshot.getValue(UserData.class);
                    homeDataList.add(userData);
                }
                infoAdapter.setData(homeDataList);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle any database error
            }
        });
    }



    // RecyclerView Adapter
    // RecyclerView Adapter
    public class InfoAdapter extends RecyclerView.Adapter<InfoAdapter.InfoViewHolder> {
        private List<UserData> dataList;

        public InfoAdapter() {
            this.dataList = new ArrayList<>();
        }

        public void setData(List<UserData> dataList) {
            this.dataList = dataList;
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public InfoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_info, parent, false);
            return new InfoViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull InfoViewHolder holder, int position) {
            UserData homeData = dataList.get(position);
            holder.nameTextView.setText(homeData.getName());

            // Retrieve the ID of the current home
            String homeId = homeData.getId();
            // Pass the home ID to the click listener
            holder.checkButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = holder.getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        UserData homeData = dataList.get(position);
                        String name = homeData.getName();
                        String address = homeData.getAddress();
                        String phoneNumber = homeData.getPhone();

                        // Perform actions with the retrieved information, such as displaying it in a new activity or fragment
                        Intent intent = new Intent(FindHomes.this, RequirementActivity.class);
                        intent.putExtra("homeId", homeId); // Pass the home ID to the RequirementActivity
                        intent.putExtra("name", name);
                        intent.putExtra("address", address);
                        intent.putExtra("phoneNumber", phoneNumber);
                        startActivity(intent);
                    }
                }
            });
        }

        @Override
        public int getItemCount() {
            return dataList.size();
        }

        public class InfoViewHolder extends RecyclerView.ViewHolder {
            private TextView nameTextView;
            private Button checkButton;

            public InfoViewHolder(View itemView) {
                super(itemView);
                nameTextView = itemView.findViewById(R.id.nameTextView);
                checkButton = itemView.findViewById(R.id.checkBtn);
            }
        }
    }

}