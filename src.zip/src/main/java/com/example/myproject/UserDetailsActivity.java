package com.example.myproject;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class UserDetailsActivity extends AppCompatActivity {

    private TextView nameTextView;
    private TextView addressTextView;
    private TextView phoneNumberTextView;
    private EditText requirementEditText;
    private Button addRequirementButton;
    private TableLayout requirementTable;

    private DatabaseReference databaseReference;
    private List<String> requirementList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_details);
        requirementList = new ArrayList<>();

        // Retrieve the passed data from the Intent extras
        String name = getIntent().getStringExtra("name");
        String address = getIntent().getStringExtra("address");
        String phoneNumber = getIntent().getStringExtra("phoneNumber");

        // Initialize the TextViews
        nameTextView = findViewById(R.id.nameTextView);
        addressTextView = findViewById(R.id.addressTextView);
        phoneNumberTextView = findViewById(R.id.phoneNumberTextView);
        requirementEditText = findViewById(R.id.requirementEditText);
        addRequirementButton = findViewById(R.id.addRequirementButton);
        requirementTable = findViewById(R.id.requirementTable);

        // Set the retrieved data to the TextViews
        nameTextView.setText(name);
        addressTextView.setText(address);
        phoneNumberTextView.setText(phoneNumber);

        // Get a reference to the Firebase Realtime Database
        databaseReference = FirebaseDatabase.getInstance().getReference().child("users")
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                .child("requirements");

        // Read the requirements from Firebase and update the UI
        readRequirements();

        addRequirementButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String requirement = requirementEditText.getText().toString().trim();
                if (!TextUtils.isEmpty(requirement)) {
                    addRequirement(requirement);
                    requirementEditText.setText("");

                    // Add the requirement to the requirements list
                    requirementList.add(requirement);
                }
            }
        });

        Button saveButton = findViewById(R.id.saveButton);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveRequirements();
            }
        });

    }


    private void readRequirements() {
        DatabaseReference userRequirementsRef = FirebaseDatabase.getInstance()
                .getReference()
                .child("users")
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                .child("requirements");

        userRequirementsRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                requirementTable.removeAllViews();

                // Iterate through each requirement in the dataSnapshot
                for (DataSnapshot requirementSnapshot : dataSnapshot.getChildren()) {
                    // Get the requirement key and data
                    String requirementKey = requirementSnapshot.getKey();
                    String requirementName = requirementSnapshot.child("name").getValue(String.class);
                    Long requirementCountLong = requirementSnapshot.child("count").getValue(Long.class);

                    // Check if requirement count is null
                    long requirementCount = 0; // Default value if count is null
                    if (requirementCountLong != null) {
                        requirementCount = requirementCountLong;
                    }

                    // Create a new TableRow to hold the requirement item
                    TableRow requirementRow = new TableRow(UserDetailsActivity.this);
                    TableRow.LayoutParams layoutParams = new TableRow.LayoutParams(
                            TableRow.LayoutParams.MATCH_PARENT,
                            TableRow.LayoutParams.WRAP_CONTENT
                    );
                    requirementRow.setLayoutParams(layoutParams);

                    // Create a new TextView to display the requirement name and count
                    TextView requirementTextView = new TextView(UserDetailsActivity.this);
                    TableRow.LayoutParams textLayoutParams = new TableRow.LayoutParams(
                            TableRow.LayoutParams.MATCH_PARENT,
                            TableRow.LayoutParams.WRAP_CONTENT
                    );
                    textLayoutParams.weight = 1;
                    requirementTextView.setLayoutParams(textLayoutParams);
                    requirementTextView.setText(requirementName + ": " + requirementCount);
                    requirementTextView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22); // Set the text size to 18sp
                    requirementTextView.setTypeface(ResourcesCompat.getFont(UserDetailsActivity.this, R.font.alata));


                    // Create a new Button for editing the requirement count
                    Button editButton = new Button(UserDetailsActivity.this);
                    TableRow.LayoutParams editButtonLayoutParams = new TableRow.LayoutParams(
                            TableRow.LayoutParams.WRAP_CONTENT,
                            TableRow.LayoutParams.WRAP_CONTENT
                    );
                    editButtonLayoutParams.weight = 1;
                    editButton.setLayoutParams(editButtonLayoutParams);
                    editButton.setCompoundDrawablesWithIntrinsicBounds(R.drawable.baseline_edit_24, 0, 0, 0);
                    editButton.setBackground(null);
                    editButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            showQuantityDialog(requirementTextView, requirementKey);
                        }
                    });

                    // Create a new Button for deleting the requirement
                    Button deleteButton = new Button(UserDetailsActivity.this);
                    TableRow.LayoutParams deleteButtonLayoutParams = new TableRow.LayoutParams(
                            TableRow.LayoutParams.WRAP_CONTENT,
                            TableRow.LayoutParams.WRAP_CONTENT
                    );
                    deleteButtonLayoutParams.weight = 1;
                    deleteButton.setLayoutParams(deleteButtonLayoutParams);
                    deleteButton.setCompoundDrawablesWithIntrinsicBounds(R.drawable.baseline_delete_24, 0, 0, 0);
                    deleteButton.setBackground(null);
                    deleteButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            showDeleteConfirmationDialog(requirementKey, requirementRow);
                        }
                    });

                    // Add the TextViews and Buttons to the TableRow
                    requirementRow.addView(requirementTextView);
                    requirementRow.addView(editButton);
                    requirementRow.addView(deleteButton);

                    // Add the TableRow to the TableLayout
                    requirementTable.addView(requirementRow);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle any errors that occur during data retrieval
                Toast.makeText(UserDetailsActivity.this, "Failed to read requirements", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void addRequirement(String requirement) {
        // Save the requirement name and count to Firebase Realtime Database
        String requirementKey = databaseReference.push().getKey();
        if (requirementKey != null) {
            RequirementItem requirementItem = new RequirementItem(requirement, 0);
            databaseReference.child(requirementKey).setValue(requirementItem)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(UserDetailsActivity.this, "Requirement added successfully",
                                        Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(UserDetailsActivity.this, "Failed to add requirement",
                                        Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        }
    }



    private void showQuantityDialog(TextView requirementTextView, String requirementKey) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Quantity");

        // Create a number picker for the quantity
        NumberPicker numberPicker = new NumberPicker(this);
        numberPicker.setMinValue(0);
        numberPicker.setMaxValue(100);

        // Set the current quantity based on the requirement text
        String requirement = requirementTextView.getText().toString();
        int currentQuantity = 0; // Default value if requirement doesn't have quantity
        int indexOfColon = requirement.lastIndexOf(":");
        if (indexOfColon != -1 && indexOfColon + 2 < requirement.length()) {
            String quantityString = requirement.substring(indexOfColon + 2);
            try {
                currentQuantity = Integer.parseInt(quantityString);
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        numberPicker.setValue(currentQuantity);

        builder.setView(numberPicker);
        builder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                int newQuantity = numberPicker.getValue();
                String updatedRequirement = requirementTextView.getText().toString().split(":")[0] + ": " + newQuantity;
                requirementTextView.setText(updatedRequirement);

                // Update the requirement in Firebase
                updateRequirementCount(requirementKey, newQuantity);
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        builder.create().show();
    }

    private void updateRequirementCount(final String requirementKey, final int newCount) {
        // Update the count in Firebase Realtime Database
        DatabaseReference requirementRef = databaseReference.child(requirementKey);
        requirementRef.child("count").setValue(newCount)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            // Update the countTextView with the new value
                            TableRow requirementRow = findRequirementRow(requirementKey);
                            if (requirementRow != null) {
                                TextView countTextView = (TextView) requirementRow.getChildAt(1);
                                countTextView.setText(String.valueOf(newCount));
                            }
                            Toast.makeText(UserDetailsActivity.this, "Requirement count updated successfully",
                                    Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(UserDetailsActivity.this, "Failed to update requirement count",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }


    private TableRow findRequirementRow(String requirementKey) {
        int rowCount = requirementTable.getChildCount();

        for (int i = 0; i < rowCount; i++) {
            View rowView = requirementTable.getChildAt(i);
            if (rowView instanceof TableRow) {
                TableRow row = (TableRow) rowView;
                TextView requirementTextView = (TextView) row.getChildAt(0);
                String requirementName = requirementTextView.getText().toString();
                if (requirementName.equals(requirementKey)) {
                    return row;
                }
            }
        }

        return null;
    }



    private void showDeleteConfirmationDialog(final String requirementKey, final TableRow requirementRow) {
        AlertDialog.Builder builder = new AlertDialog.Builder(UserDetailsActivity.this);
        builder.setTitle("Confirm Delete");
        builder.setMessage("Are you sure you want to delete this requirement?");

        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                deleteRequirement(requirementKey, requirementRow);
            }
        });

        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Cancel dialog
            }
        });

        builder.show();
    }

    private void deleteRequirement(String requirementKey, TableRow requirementRow) {
        // Remove the requirement from Firebase Realtime Database
        databaseReference.child(requirementKey).removeValue()
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            // Remove the TableRow from the TableLayout
                            requirementTable.removeView(requirementRow);
                            Toast.makeText(UserDetailsActivity.this, "Requirement deleted successfully",
                                    Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(UserDetailsActivity.this, "Failed to delete requirement",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void saveRequirements() {
        // Get the number of rows in the TableLayout
        int rowCount = requirementTable.getChildCount();

        // Create a Map to hold the requirements and their counts
        Map<String, Long> requirements = new HashMap<>();

        // Iterate through each row and save the requirement names and counts
        for (int i = 0; i < rowCount; i++) {
            View rowView = requirementTable.getChildAt(i);
            if (rowView instanceof TableRow) {
                TableRow row = (TableRow) rowView;
                TextView requirementTextView = (TextView) row.getChildAt(0);
                TextView countTextView = (TextView) row.getChildAt(1);

                String requirementName = requirementTextView.getText().toString();
                long requirementCount = Long.parseLong(countTextView.getText().toString());

                // Add the requirement to the Map
                requirements.put(requirementName, requirementCount);
            }
        }

        // Get the user's ID from Firebase Auth
        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();

        // Get a reference to the user's requirements in Firebase
        DatabaseReference userRequirementsRef = FirebaseDatabase.getInstance()
                .getReference()
                .child("users")
                .child(userId)
                .child("requirements");

        // Save the requirements to Firebase
        userRequirementsRef.setValue(requirements)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(UserDetailsActivity.this, "Requirements saved successfully", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(UserDetailsActivity.this, "Failed to save requirements", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

}