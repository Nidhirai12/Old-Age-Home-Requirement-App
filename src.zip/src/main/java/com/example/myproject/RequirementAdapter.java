package com.example.myproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.util.List;

public class RequirementAdapter extends ArrayAdapter<String> {
    private Context context;
    private List<String> requirements;

    public RequirementAdapter(Context context, List<String> requirements) {
        super(context, 0, requirements);
        this.context = context;
        this.requirements = requirements;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        ViewHolder viewHolder;

        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_requirement, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.requirementNameTextView = convertView.findViewById(R.id.requirementNameTextView);
            viewHolder.countTextView = convertView.findViewById(R.id.countTextView);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        String requirement = requirements.get(position);
        String[] parts = requirement.split(": ");
        String requirementName = parts[0];
        String count = parts[1];

        viewHolder.requirementNameTextView.setText(requirementName);
        viewHolder.countTextView.setText(count);

        return convertView;
    }

    private static class ViewHolder {
        TextView requirementNameTextView;
        TextView countTextView;
    }
}
